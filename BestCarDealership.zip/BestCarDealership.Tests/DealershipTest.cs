﻿using BestCarDealership.BL.Services;
using BestCarDealership.DL.Interfaces;
using BestCarDealership.Models;
using Moq;

namespace BestCarDealership.Tests
{
    public class DealershipTest
    {
        public static List<Dealership> DealershipData = new List<Dealership>()
        {
            new Dealership()
            {
                Id = 1,
                Name = "ABC Motors",
                Location = "123 Main St",
                Inventory = new List<Car>
                {
                    new Car()
                    {
                        Id = 1,
                        Make = "Toyota",
                        Model = "Camry",
                        Year = 2020,
                        Price = 25000.00
                    }
                }
            },
            new Dealership()
            {
                Id = 2,
                Name = "XYZ Cars",
                Location = "456 Elm St",
                Inventory = new List<Car>
                {
                    new Car()
                    {
                        Id = 2,
                        Make = "Honda",
                        Model = "Civic",
                        Year = 2018,
                        Price = 20000.00
                    }
                }
            },
            new Dealership()
            {
                Id = 3,
                Name = "123 Auto",
                Location = "789 Oak St",
                Inventory = new List<Car>
                {
                    new Car()
                    {
                        Id = 3,
                        Make = "Ford",
                        Model = "Escape",
                        Year = 2022,
                        Price = 30000.00
                    }
                }
            }
        };

        [Fact]
        public void GetDealershipById_ShouldReturnCorrectDealership()
        {
            // Arrange
            var expectedDealershipId = 3;
            var mockedDealershipRepository = new Mock<IDealershipRepository>();
            mockedDealershipRepository.Setup(x => x.GetDealershipById(expectedDealershipId))
                .Returns(DealershipData.Find(d => d.Id == expectedDealershipId));
            var service = new DealershipService(mockedDealershipRepository.Object);

            // Act
            var result = service.GetDealershipById(expectedDealershipId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedDealershipId, result.Id);
        }

        [Fact]
        public void GetAllDealerships_ShouldReturnAllDealerships()
        {
            // Arrange
            var expectedCount = 3;
            var mockedDealershipRepository = new Mock<IDealershipRepository>();
            mockedDealershipRepository.Setup(x => x.GetAllDealerships())
                .Returns(DealershipData);
            var service = new DealershipService(mockedDealershipRepository.Object);

            // Act
            var result = service.GetAllDealerships();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedCount, result.Count);
        }

        [Fact]
        public void AddDealership_ShouldIncreaseDealershipCount()
        {
            // Arrange
            var expectedCount = 3;
            var newDealership = new Dealership()
            {
                Id = 4,
                Name = "New Dealership",
                Location = "456 New St",
                Inventory = new List<Car>
                {
                    new Car()
                    {
                        Id = 4,
                        Make = "Nissan",
                        Model = "Altima",
                        Year = 2021,
                        Price = 28000.00
                    }
                }
            };
            var mockedDealershipRepository = new Mock<IDealershipRepository>();
            mockedDealershipRepository.Setup(x => x.AddDealership(newDealership)).Callback(() =>
            {
                DealershipData.Add(newDealership);
            });
            var service = new DealershipService(mockedDealershipRepository.Object);

            // Act
            service.AddDealership(newDealership);

            // Assert
            Assert.Equal(expectedCount, DealershipData.Count);
        }

        [Fact]
        public void RemoveDealership_ShouldDecreaseDealershipCount()
        {
            // Arrange
            var expectedCount = 2;
            var dealershipId = 1;
            var mockedDealershipRepository = new Mock<IDealershipRepository>();
            mockedDealershipRepository.Setup(x => x.RemoveDealership(dealershipId)).Callback(() =>
            {
                DealershipData.RemoveAll(d => d.Id == dealershipId);
            });
            var service = new DealershipService(mockedDealershipRepository.Object);

            // Act
            service.RemoveDealership(dealershipId);

            // Assert
            Assert.Equal(expectedCount, DealershipData.Count);
        }
    }
}
