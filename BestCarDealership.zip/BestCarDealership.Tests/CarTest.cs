﻿using BestCarDealership.BL.Services;
using BestCarDealership.DL.Interfaces;
using BestCarDealership.Models;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BestCarDealership.Tests
{
    public class CarTest
    {
        public static List<Car> CarData = new List<Car>()
        {
            new Car()
            {
                Id = 1,
                Make = "Toyota",
                Model = "Camry",
                Year = 2020,
                Price = 25000.00
            },
            new Car()
            {
                Id = 2,
                Make = "Honda",
                Model = "Civic",
                Year = 2018,
                Price = 20000.00
            },
            new Car()
            {
                Id = 3,
                Make = "Ford",
                Model = "Escape",
                Year = 2022,
                Price = 30000.00
            },
            new Car()
            {
                Id = 4,
                Make = "Toyota",
                Model = "Corrola",
                Year = 2002,
                Price = 99_000.00
            }
        };

        [Fact]
        public void GetAllByMake_Count_Check()
        {
            var expectedCount = 2;
            var make = "Toyota";

            var mockedCarRepository = new Mock<ICarRepository>();
            mockedCarRepository
                .Setup(x => x.GetAllCars())
                .Returns(CarData.Where(c => c.Make == make).ToList());

            var service = new CarService(mockedCarRepository.Object);

            var result = service.GetAllCars();

            Assert.NotNull(result);
            Assert.Equal(expectedCount, result.Count());
        }

        [Fact]
        public void GetAllByMake_WrongMake()
        {
            var expectedCount = 0;
            var make = "Chevrolet";

            var mockedCarRepository = new Mock<ICarRepository>();
            mockedCarRepository.Setup(x => x.GetAllCarsByMake(make))
                .Returns(CarData.Where(c => c.Make == make).ToList());

            var service = new CarService(mockedCarRepository.Object);

            var result = service.GetCarsByMake(make);

            Assert.NotNull(result);
            Assert.Equal(expectedCount, result.Count());
        }

        [Fact]
        public void Remove_Count_Check()
        {
            var expectedResult = 3;
            var carId = 1;
            var carToRemove = CarData.FirstOrDefault(x => x.Id == carId);

            var mockedCarRepository = new Mock<ICarRepository>();
            mockedCarRepository.Setup(x => x.RemoveCar(carId)).Callback(() =>
            {
                CarData.Remove(carToRemove);
            });

            var service = new CarService(mockedCarRepository.Object);

            service.RemoveCar(carId);

            Assert.Equal(expectedResult, CarData.Count);
        }
    }
}
