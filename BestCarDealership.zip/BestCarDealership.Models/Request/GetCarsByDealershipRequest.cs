﻿namespace BestCarDealership.Models.Request
{
    public class GetCarsByDealershipRequest
    {
        public int DealershipId { get; set; }
    }
}
