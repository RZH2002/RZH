﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BestCarDealership.Models
{
    public abstract class BaseClass
    {
        public int Id { get; set; }

        public BaseClass()
        {
            
        }

        public BaseClass(int id)
        {
            this.Id = id;
        }
    }
}
