﻿using BestCarDealership.Models.Request;

namespace BestCarDealership.BL.Interfaces
{
    public interface ICarDealershipService
    {
        GetCarsByDealershipResponse? GetCarsByDealership(GetCarsByDealershipRequest request);
    }
}
