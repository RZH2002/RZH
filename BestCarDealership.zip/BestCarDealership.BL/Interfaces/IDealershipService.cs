﻿using BestCarDealership.Models;

namespace BestCarDealership.BL.Interfaces
{
    public interface IDealershipService
    {
        List<Dealership> GetAllDealerships();

        Dealership GetDealershipById(int id);

        void AddDealership(Dealership dealership);

        void RemoveDealership(int id);

        List<Car> GetDealershipInventory(int dealershipId);
    }
}
