﻿using BestCarDealership.Models;

namespace BestCarDealership.BL.Interfaces
{
    public interface ICarService
    {
        List<Car> GetAllCars();

        Car GetCarById(int id);

        void AddCar(Car car);
        void RemoveCar(int id);

        List<Car> GetCarsByDealershipId(int dealershipId);
    }
}
