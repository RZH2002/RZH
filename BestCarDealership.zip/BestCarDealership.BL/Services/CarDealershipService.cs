﻿using BestCarDealership.BL.Interfaces;
using BestCarDealership.Models.Request;

namespace BestCarDealership.BL.Services
{
    public class CarDealershipService : ICarDealershipService
    {
        private readonly ICarService _carService;
        private readonly IDealershipService _dealershipService;

        public CarDealershipService(ICarService carService, IDealershipService dealershipService)
        {
            _carService = carService;
            _dealershipService = dealershipService;
        }

        public GetCarsByDealershipResponse? GetCarsByDealership(GetCarsByDealershipRequest request)
        {
            var cars = _carService.GetCarsByDealershipId(request.DealershipId);
            var foundCars = cars != null && cars.Count > 0;

            var dealer = _dealershipService.GetDealershipById(request.DealershipId);
            var foundDealer = dealer != null;

            if (!foundCars || !foundDealer)
            {
                return null;
            }

            var response = new GetCarsByDealershipResponse
            {
                Dealership = dealer,
                Cars = dealer.Inventory,
            };

            return response;
        }
    }
}
