﻿using BestCarDealership.BL.Interfaces;
using BestCarDealership.DL.Interfaces;
using BestCarDealership.Models;

namespace BestCarDealership.BL.Services
{
    public class CarService : ICarService
    {
        private readonly ICarRepository _carRepository;

        public CarService(ICarRepository carRepository)
        {
            _carRepository = carRepository;
        }

        public List<Car> GetAllCars()
        {
            return _carRepository.GetAllCars();
        }

        public Car GetCarById(int id)
        {
            return _carRepository.GetCarById(id);
        }

        public void AddCar(Car car)
        {
            _carRepository.AddCar(car);
        }

        public void RemoveCar(int id)
        {
            _carRepository.RemoveCar(id);
        }

        public List<Car> GetCarsByDealershipId(int dealershipId)
        {
            return _carRepository.GetAllCarsByDealershipId(dealershipId);
        }

        public List<Car> GetCarsByMake(string make)
        {
            return _carRepository.GetAllCarsByMake(make);
        }
    }
}
