﻿using BestCarDealership.BL.Interfaces;
using BestCarDealership.DL.Interfaces;
using BestCarDealership.Models;

namespace BestCarDealership.BL.Services
{
    public class DealershipService : IDealershipService
    {
        private readonly IDealershipRepository _dealershipRepository;

        public DealershipService(IDealershipRepository dealershipRepository)
        {
            _dealershipRepository = dealershipRepository;
        }

        public List<Dealership> GetAllDealerships()
        {
            return _dealershipRepository.GetAllDealerships();
        }

        public Dealership GetDealershipById(int id)
        {
            return _dealershipRepository.GetDealershipById(id);
        }

        public void AddDealership(Dealership dealership)
        {
            _dealershipRepository.AddDealership(dealership);
        }

        public void RemoveDealership(int id)
        {
            _dealershipRepository.RemoveDealership(id);
        }

        public List<Car> GetDealershipInventory(int dealershipId)
        {
            return _dealershipRepository.GetDealershipInventory(dealershipId);
        }
    }
}
